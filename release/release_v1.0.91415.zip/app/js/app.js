(function () {
    'use strict';
     angular.module('googleExtensionVK', []);
})();

$(document).ready(function (){
});