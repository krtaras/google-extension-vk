(function () {
    'use strict';
     angular.module('googleExtensionVK', []);
})();

function getSpinnerHtml() {
    return '<div class="spinner"></div>';
}